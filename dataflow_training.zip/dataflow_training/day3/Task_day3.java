package com.hsbc.training.pipeline;

import java.util.Map;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hsbc.training.pipeline.entity.CombinedTradeResult;
import com.hsbc.training.pipeline.entity.CompositeID;
import com.hsbc.training.pipeline.entity.LegalDoc;
import com.hsbc.training.pipeline.entity.Trade;
import com.hsbc.training.pipeline.function.ParseLegalDocFn;
import com.hsbc.training.pipeline.function.ParseTradeAttributeFn;
import com.hsbc.training.pipeline.function.TradeResultFn;
import com.hsbc.training.pipeline.transform.CombineTimestepTradeResultCompositeTransform;
import com.hsbc.training.pipeline.transform.SplitTradeByLegalDocCompositeTransform;

public class Task_day3 {

	private static final Logger LOG = LoggerFactory.getLogger(NormalFlowPipeline.class);

	public static void main(String[] args) {
		PipelineOptionsFactory.register(CustomOptions.class);
		CustomOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(CustomOptions.class);
		Pipeline pipeline = Pipeline.create(options);
		
		//parse source file
		PCollection<String> result = pipeline.apply("Read TradeResult", TextIO.read().from(options.getTradeResult()));
		PCollection<String> trade = pipeline.apply("Read TradeAttribute", TextIO.read().from(options.getTrade()));
		PCollection<String> legalDoc = pipeline.apply("Read LegalDoc", TextIO.read().from(options.getLegalDoc()));

		//source to map, trade id - trade
		PCollectionView<Map<String, Trade>> tradeMap = trade
				.apply("Parse Line to Trade Map", ParDo.of(new ParseTradeAttributeFn()))
				.apply("View.asMap", View.asMap());
		
		//legaldoc id - legaldoc
		PCollectionView<Map<String, LegalDoc>> legalDocMap = legalDoc
				.apply("Parse Line to LegalDoc Map", ParDo.of(new ParseLegalDocFn()))
				.apply("View.asMap", View.asMap());
		
		//trade id - trade result
		PCollection<KV<String, CombinedTradeResult>> tradeResult = result
				.apply("Parse Line to TradeResult", ParDo.of(TradeResultFn.readFile()))
				.apply(new CombineTimestepTradeResultCompositeTransform());

		TupleTag<KV<CompositeID, Map<String, double[]>>> nodoc = new TupleTag<KV<CompositeID, Map<String, double[]>>>() {
		};
		TupleTag<KV<CompositeID, Map<String, double[]>>> closeout = new TupleTag<KV<CompositeID, Map<String, double[]>>>() {
		};
		TupleTag<KV<CompositeID, Map<String, double[]>>> collateral = new TupleTag<KV<CompositeID, Map<String, double[]>>>() {
		};

		//construct the result by side input
		PCollectionTuple resultTuple = tradeResult
				.apply(new SplitTradeByLegalDocCompositeTransform(tradeMap, legalDocMap, nodoc, closeout, collateral));

}
