import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @SuppressWarnings("unchecked")
  @Test
  public void combine_combineFn() {
    Create.Values<KV<String, Integer>> values = Create.of(
        KV.of(Task.PLAYER_1, 15), KV.of(Task.PLAYER_2, 10), KV.of(Task.PLAYER_1, 100),
        KV.of(Task.PLAYER_3, 25), KV.of(Task.PLAYER_2, 75)
    );
    PCollection<KV<String, Integer>> numbers = testPipeline.apply(values);

    PCollection<KV<String, Integer>> results = Task.applyTransform(numbers);

    PAssert.that(results)
        .containsInAnyOrder(
            KV.of(Task.PLAYER_1, 115), KV.of(Task.PLAYER_2, 85), KV.of(Task.PLAYER_3, 25)
        );

    testPipeline.run().waitUntilFinish();
  }

}