import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void combine_combineFn() {
    Create.Values<Integer> values = Create.of(10, 20, 50, 70, 90);
    PCollection<Integer> numbers = testPipeline.apply(values);

    PCollection<Double> results = Task.applyTransform(numbers);

    PAssert.that(results)
        .containsInAnyOrder(48.0);

    testPipeline.run().waitUntilFinish();
  }

}