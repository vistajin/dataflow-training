import java.math.BigInteger;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void combine_binaryCombineFn() {
    Create.Values<BigInteger> values = Create.of(
        BigInteger.valueOf(10), BigInteger.valueOf(20), BigInteger.valueOf(30),
        BigInteger.valueOf(40), BigInteger.valueOf(50)
    );
    PCollection<BigInteger> numbers = testPipeline.apply(values);

    PCollection<BigInteger> results = Task.applyTransform(numbers);

    PAssert.that(results)
        .containsInAnyOrder(BigInteger.valueOf(150));

    testPipeline.run().waitUntilFinish();
  }

}