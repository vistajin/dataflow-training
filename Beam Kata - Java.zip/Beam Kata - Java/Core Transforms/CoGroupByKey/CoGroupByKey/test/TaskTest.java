import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void coGroupByKey() {
    PCollection<String> fruits =
        testPipeline.apply("Fruits",
            Create.of("apple", "banana", "cherry")
        );

    PCollection<String> countries =
        testPipeline.apply("Countries",
            Create.of("australia", "brazil", "canada")
        );

    PCollection<String> results = Task.applyTransform(fruits, countries);

    PAssert.that(results)
        .containsInAnyOrder(
            "WordsAlphabet{alphabet='a', fruit='apple', country='australia'}",
            "WordsAlphabet{alphabet='b', fruit='banana', country='brazil'}",
            "WordsAlphabet{alphabet='c', fruit='cherry', country='canada'}"
        );

    testPipeline.run().waitUntilFinish();
  }

}