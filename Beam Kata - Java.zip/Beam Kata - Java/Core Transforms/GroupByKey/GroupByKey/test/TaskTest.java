import static test.util.ContainsKvs.containsKvs;

import com.google.common.collect.ImmutableList;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void groupByKey() {
    Create.Values<String> values = Create.of("apple", "ball", "car", "bear", "cheetah", "ant");
    PCollection<String> numbers = testPipeline.apply(values);

    PCollection<KV<String, Iterable<String>>> results = Task.applyTransform(numbers);

    PAssert.that(results)
        .satisfies(
            containsKvs(
                KV.of("a", ImmutableList.of("apple", "ant")),
                KV.of("b", ImmutableList.of("ball", "bear")),
                KV.of("c", ImmutableList.of("car", "cheetah"))
            )
        );

    testPipeline.run().waitUntilFinish();
  }

}