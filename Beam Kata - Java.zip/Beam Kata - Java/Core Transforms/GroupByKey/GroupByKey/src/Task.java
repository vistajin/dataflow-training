import static org.apache.beam.sdk.values.TypeDescriptors.kvs;
import static org.apache.beam.sdk.values.TypeDescriptors.strings;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import util.Log;

class Task {

  public static void main(String[] args) {
    PipelineOptions options = PipelineOptionsFactory.fromArgs(args).create();
    Pipeline pipeline = Pipeline.create(options);

    PCollection<String> words =
        pipeline.apply(
            Create.of("apple", "ball", "car", "bear", "cheetah", "ant")
        );

    PCollection<KV<String, Iterable<String>>> output = applyTransform(words);

    output.apply(Log.ofElements());

    pipeline.run();
  }

  static PCollection<KV<String, Iterable<String>>> applyTransform(PCollection<String> input) {
    return input
            .apply(MapElements.into(kvs(strings(), strings()))
              .via(w -> KV.of(w.substring(0, 1), w)))
            .apply(GroupByKey.create());

  }

}