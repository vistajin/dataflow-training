import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void flatten() {
    PCollection<String> wordsStartingWithA =
        testPipeline.apply("Words starting with A",
            Create.of("apple", "ant", "arrow"));
    PCollection<String> wordsStartingWithB =
        testPipeline.apply("Words starting with B",
            Create.of("ball", "book", "bow"));

    PCollection<String> results = Task.applyTransform(wordsStartingWithA, wordsStartingWithB);

    PAssert.that(results)
        .containsInAnyOrder("apple", "ant", "arrow", "ball", "book", "bow");

    testPipeline.run().waitUntilFinish();
  }

}