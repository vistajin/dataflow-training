import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void flatMapElements() {
    Create.Values<String> values = Create.of("Apache Beam", "Unified Batch and Streaming");
    PCollection<String> numbers = testPipeline.apply(values);

    PCollection<String> results = Task.applyTransform(numbers);

    PAssert.that(results)
        .containsInAnyOrder("Apache", "Beam", "Unified", "Batch", "and", "Streaming");

    testPipeline.run().waitUntilFinish();
  }

}