import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void parDo_oneToMany() {
    Create.Values<String> values = Create.of("Hello Beam", "It is awesome");
    PCollection<String> numbers = testPipeline.apply(values);

    PCollection<String> results = Task.applyTransform(numbers);

    PAssert.that(results)
        .containsInAnyOrder("Hello", "Beam", "It", "is", "awesome");

    testPipeline.run().waitUntilFinish();
  }

}