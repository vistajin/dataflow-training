import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void mapElements() {
    Create.Values<Integer> values = Create.of(10, 20, 30, 40, 50);
    PCollection<Integer> numbers = testPipeline.apply(values);

    PCollection<Integer> results = Task.applyTransform(numbers);

    PAssert.that(results)
        .containsInAnyOrder(50, 100, 150, 200, 250);

    testPipeline.run().waitUntilFinish();
  }

}