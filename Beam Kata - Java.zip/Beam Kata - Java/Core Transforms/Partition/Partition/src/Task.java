import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.Partition;
import org.apache.beam.sdk.transforms.Partition.PartitionFn;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import util.Log;

class Task {

  public static void main(String[] args) {
    PipelineOptions options = PipelineOptionsFactory.fromArgs(args).create();
    Pipeline pipeline = Pipeline.create(options);

    PCollection<Integer> numbers =
            pipeline.apply(
                    Create.of(1, 2, 3, 4, 5, 100, 110, 150, 250)
            );

    PCollectionList<Integer> partition = applyTransform(numbers);

    partition.get(0).apply(Log.ofElements("Number > 100: "));
    partition.get(1).apply(Log.ofElements("Number <= 100: "));

    pipeline.run();
  }

  static PCollectionList<Integer> applyTransform(PCollection<Integer> input) {
    return input.apply(Partition.of(2, new PartitionFn<Integer>() {
      public int partitionFor(Integer input, int numPartitions) {
        return (input > 100) ? 0 : 1;
      }
    }));
  }

}