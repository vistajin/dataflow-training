import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionList;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void groupByKey() {
    PCollection<Integer> numbers =
        testPipeline.apply(
            Create.of(1, 2, 3, 4, 5, 100, 110, 150, 250)
        );

    PCollectionList<Integer> results = Task.applyTransform(numbers);

    PAssert.that(results.get(0))
        .containsInAnyOrder(110, 150, 250);

    PAssert.that(results.get(1))
        .containsInAnyOrder(1, 2, 3, 4, 5, 100);

    testPipeline.run().waitUntilFinish();
  }

}