import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest {

  @Rule
  public TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void sum() {
    Create.Values<Integer> values = Create.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
    PCollection<Integer> numbers = testPipeline.apply(values);

    PCollection<Integer> results = Task.applyTransform(numbers);

    PAssert.that(results)
        .containsInAnyOrder(55);

    testPipeline.run().waitUntilFinish();
  }

}