package test.util;

import org.apache.beam.sdk.values.KV;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

public class KvMatcher<K, V> extends TypeSafeMatcher<KV<? extends K, ? extends V>> {

  private final Matcher<? super K> keyMatcher;
  private final Matcher<? super V> valueMatcher;

  public KvMatcher(Matcher<? super K> keyMatcher,
      Matcher<? super V> valueMatcher) {
    this.keyMatcher = keyMatcher;
    this.valueMatcher = valueMatcher;
  }

  public static <K, V> KvMatcher<K, V> isKv(Matcher<K> keyMatcher,
      Matcher<V> valueMatcher) {
    return new KvMatcher<>(keyMatcher, valueMatcher);
  }

  @Override
  public boolean matchesSafely(KV<? extends K, ? extends V> kv) {
    return keyMatcher.matches(kv.getKey())
        && valueMatcher.matches(kv.getValue());
  }

  @Override
  public void describeTo(Description description) {
    description
        .appendText("a KV(").appendValue(keyMatcher)
        .appendText(", ").appendValue(valueMatcher)
        .appendText(")");
  }

}
