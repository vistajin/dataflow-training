import java.io.Serializable;
import org.apache.beam.sdk.testing.PAssert;
import org.apache.beam.sdk.testing.TestPipeline;
import org.apache.beam.sdk.values.PCollection;
import org.junit.Rule;
import org.junit.Test;

public class TaskTest implements Serializable {

  @Rule
  public final transient TestPipeline testPipeline = TestPipeline.create();

  @Test
  public void helloWorld() {
    PCollection<String> results = Task.setupPipeline(testPipeline);

    PAssert.that(results)
        .containsInAnyOrder("Hello Beam");

    testPipeline.run().waitUntilFinish();
  }

}