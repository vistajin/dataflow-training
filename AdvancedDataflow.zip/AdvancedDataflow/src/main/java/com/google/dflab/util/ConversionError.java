/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.beam.sdk.coders.AvroCoder;
import org.apache.beam.sdk.coders.DefaultCoder;
    

/**
 * custom DTO to contain error information created during the validation phase
 * this can be written to BQ.
 *  
 * @author stephanmeyn
 *
 */
@DefaultCoder(AvroCoder.class)
public class ConversionError {
	String msg;
	int colIdx;
	String name;
	String dType;
	String value;
	String createdDate;  // can't use date time as AvroCoder won't handle it.
	
	/** default constructor required for Avro */
	public ConversionError() {
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
		createdDate =    dateFormatter.format (new Date() );
	}

	public ConversionError(String msg, int colIdx, String name, List<String> row) {
		this.msg = msg;
		this.colIdx = colIdx;
		this.name = name;
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
		createdDate =    dateFormatter.format (new Date() );

		if (row.get(0) == "HDR")
			this.dType = "HDR";
		else
			this.dType = row.get(2);
		if (colIdx >= 0)
			this.value = row.get(colIdx);
	}

	public String getMsg() {
		return this.msg;
	}
	public void setMsg(String value) {
		 this.msg = value;
	}

	public int getColIdx() {
		return this.colIdx;
	}
	public void setColIdx(int value) {
		 this.colIdx = value;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String value) {
		 this.name = value;
	}
	public String getDType() {
		return this.dType;
	}
	public void setDType(String value) {
		 this.dType = value;
	}
	public String getValue() {
		return this.value;
	}
	public void setValue(String value) {
		 this.value = value;
	}
	public String getCreatedDate () {
    	return  this.createdDate ;
    }
	public void setCreatedDate( String value) {
		 this.createdDate = value   ;
		  
	}
}