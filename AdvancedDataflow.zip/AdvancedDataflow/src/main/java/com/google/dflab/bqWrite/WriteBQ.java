/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 * 
 * ReadCsv1
 * <p>
 * The example reads a simple CSV file
 *
 * <p>
 * To run this starter example locally using DirectRunner, just execute it
 * without any additional parameters from your favorite development environment.
 * use optiopns: --input=<csv inut file> --output=<output file> --headerYaml=
 * --bqErrors=<project>.<dataset>.
 * <table>
 * 
 */
package com.google.dflab.bqWrite;

import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.transforms.Sum;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.Combine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.dflab.transforms.ReadYamlFn;
import com.google.dflab.transforms.TransformWithErrorOutputFn;
import com.google.dflab.util.ConversionError;
import com.google.dflab.util.YamlCoder;
import com.google.common.collect.ImmutableList;

import java.util.Map;

import com.google.dflab.bqWrite.CustomOptions;
import com.google.dflab.transforms.CsvParserFn;

/**
 * read CSV file, enrich the columnvalues with the header file found in yaml
 * validate data types and write errors out t BQ
 * 
 * @author stephanmeyn
 *
 */
public class WriteBQ {
	private static final Logger LOG = LoggerFactory.getLogger(WriteBQ.class);

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		PipelineOptionsFactory.register(CustomOptions.class);
		CustomOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(CustomOptions.class);

		Pipeline p = Pipeline.create(options);

		// read the header file to be used as a side input
		PCollection<?> headers = p.apply("Identify File", Create.of(options.getHeaderyaml()))
				.apply("read yaml", ParDo.of(new ReadYamlFn())).setCoder(new YamlCoder());
		// convert it to a view
		PCollectionView<Map<String, Object>> headerView = (PCollectionView<Map<String, Object>>) headers
				.apply("Convert to View", View.asSingleton());

		// map using the header info
		PCollectionTuple mappedWithSideOutputs = p.apply("read csv data file", TextIO.read().from(options.getInput()))
				.apply("split into fields", ParDo.of(new CsvParserFn()))
				.apply("validate",
						ParDo.of(new TransformWithErrorOutputFn(headerView)).withSideInputs(headerView).withOutputTags(
								TransformWithErrorOutputFn.mainOutputTag,
								TupleTagList.of(TransformWithErrorOutputFn.ErrorTag)));
		// extract the main output
		PCollection<Map<String, String>> mapped = mappedWithSideOutputs.get(TransformWithErrorOutputFn.mainOutputTag);
		// extract teh error output
		PCollection<ConversionError> errors = mappedWithSideOutputs.get(TransformWithErrorOutputFn.ErrorTag);

		mapped.apply("Extract key", MapElements.via(new SimpleFunction<Map<String, String>, KV<String, Integer>>() {
			@Override
			public KV<String, Integer> apply(Map<String, String> record) {
				String key = (String) record.get("record_type");
				if (key == null) {
					key = "No Record Type field";
				}
				return KV.of(key, 1);
			}
		})).apply("count by key", Combine.<String, Integer, Integer>perKey(Sum.ofIntegers()))
				.apply("Format for output",
						MapElements.into(TypeDescriptors.strings())
								.via((KV<String, Integer> kv) -> String.format("%s: %d", kv.getKey(), kv.getValue())))
				.apply("output", TextIO.write().to(options.getOutput()));
		// write out errors
		errors.apply(
				BigQueryIO.<ConversionError>write().to(options.getBqErrorsTable())
						.withSchema(new TableSchema().setFields(ImmutableList.<TableFieldSchema>of(
								new TableFieldSchema().setName("msg").setType("STRING"),
								new TableFieldSchema().setName("colIdx").setType("INTEGER"),
								new TableFieldSchema().setName("name").setType("STRING"),
								new TableFieldSchema().setName("dType").setType("STRING"),
								new TableFieldSchema().setName("value").setType("STRING"),
								new TableFieldSchema().setName("createdDate").setType("DATETIME"))))
						.withFormatFunction(convError -> new TableRow().set("msg", convError.getMsg())
								.set("colIdx", convError.getColIdx()).set("name", convError.getName())
								.set("dType", convError.getDType()).set("value", convError.getValue())
								.set("createdDate", convError.getCreatedDate()))
						.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));

		p.run();
	}
}
