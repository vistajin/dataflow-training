/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.transforms;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

/**
 * Simple DoFn that takes a comma delimited file and parses it into its constituents
 * 
 * @author stephanmeyn
 *
 */
@SuppressWarnings("serial")
public  class CsvParserFn extends DoFn<String, List<String>> {
	@ProcessElement
	public void processElement(ProcessContext c) throws Exception {
		String inputLine = (String) c.element();

		CSVParser parser;
		try {
			parser = CSVParser.parse(inputLine, CSVFormat.DEFAULT);
			List<CSVRecord> list = parser.getRecords();
			if (list.size() > 0) {
				List<String> results = new ArrayList<String>();
				Iterator<String> iter = list.get(0).iterator();
				while (iter.hasNext()) {
					results.add(iter.next());
				}
				c.output(results);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}