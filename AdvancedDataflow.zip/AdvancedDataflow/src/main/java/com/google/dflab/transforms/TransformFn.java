/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.transforms;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.PCollectionView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.dflab.util.HeaderHelper;

/**
 * Transform a row of strings into a hashmap where the columnNames are applied
 * 
 * @author stephanmeyn
 *
 */
@SuppressWarnings("serial")
public class TransformFn extends DoFn<List<String>, Map<String, String>> {

	private static final Logger LOG = LoggerFactory.getLogger(TransformFn.class);

	private PCollectionView<Map<String, Object>> headerView;

	public TransformFn(final PCollectionView<Map<String, Object>> headerView) {
		this.headerView = headerView;
	}

	private Map<String, String> transform(List<String> row, List<Map<String, Object>> columnInfo,
			List<Map<String, Object>> extraInfo) {
		final Map<String, String> result = new HashMap<String, String>();
		// iterate columnInfo first
		if (columnInfo != null) {
			for (Map<String, Object> colData : columnInfo) {
				int colNr = (int) colData.get("column");
				if ((colNr >= 0) && (colNr < row.size())) {
					String name = (String) colData.get("name");

					String val = row.get(colNr);
					if (val == null) {
						val = "";
					}
					result.put(name, val);
				}
			}
		}
		// iterate optional extra columnInfo
		if (extraInfo != null) {
			for (Map<String, Object> colData : extraInfo) {
				int colNr = (int) colData.get("column");
				if ((colNr >= 0) && (colNr < row.size())) {
					String name = (String) colData.get("name");
					String val = row.get(colNr);
					if (val == null) {
						val = "";
					}
					result.put(name, val);
				}
			}
		}
		return result;
	}

	@ProcessElement
	public void processElement(ProcessContext c) throws Exception {
		Map<String, Object> headers = c.sideInput(this.headerView);

		List<String> row = (List<String>) c.element();
		Map<String, String> result = null;
		String mainType = row.get(0);
		List<Map<String, Object>> columnInfo = HeaderHelper.getColumnInfoList(headers, mainType); // (List<Map<String,
																									// Object>>
		// )headerInfo.get("columns");
		if (mainType.equals("HDR")) {
			result = this.transform(row, columnInfo, null);
		} else if (mainType.equals("DET")) {
			String extraName = HeaderHelper.mappedName(row.get(2));
			List<Map<String, Object>> extraInfo = HeaderHelper.getColumnInfoList(headers, row.get(2));
			result = this.transform(row, columnInfo, extraInfo);
			result.put("event_type", extraName);
		} else {
			LOG.warn(String.format(" Unidentified record Type: '%s'", mainType));
		}
		if (result != null)
			c.output(result);
	}
}
