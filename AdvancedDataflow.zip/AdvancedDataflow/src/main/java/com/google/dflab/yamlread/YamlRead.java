/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.yamlread;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.ParDo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.dflab.yamlread.CustomOptions;
import com.google.dflab.transforms.ReadYamlFn;
import com.google.dflab.util.YamlCoder;

/**
 * Sample demonstration pipeline to create a pipeline with a single value taken
 * from an input option. the DoFn transform 'ReadYamlFn' takes that file path as
 * an input parameter and reads that file as a YAML file and returns it.
 * 
 * Highlights: - setup logging - use of custom options - create an in memory
 * PCollection - call a DoFn using ParDo - use a custom coder
 * 
 * @author stephanmeyn
 *
 */
public class YamlRead {
	private static final Logger LOG = LoggerFactory.getLogger(YamlRead.class);

	public static void main(String[] args) {
		PipelineOptionsFactory.register(CustomOptions.class);
		CustomOptions options = PipelineOptionsFactory
				                 .fromArgs(args)
				                 .withValidation()
				                 .as(CustomOptions.class);

		Pipeline p = Pipeline.create(options);

		p.apply("Identify File", Create.of(options.getInput()))
		 .apply("read yaml", ParDo.of(new ReadYamlFn()))
				.setCoder(new YamlCoder());

		p.run();
	}

}
