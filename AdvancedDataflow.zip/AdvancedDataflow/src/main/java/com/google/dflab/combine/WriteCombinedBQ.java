/*
  * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.dflab.combine;

import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;
import org.apache.beam.sdk.io.gcp.bigquery.WriteResult;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.transforms.View;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.dflab.transforms.ReadYamlFn;
import com.google.dflab.transforms.TransformWithErrorOutputFn;
import com.google.dflab.util.ConversionError;
import com.google.dflab.util.MeterRecord;
import com.google.dflab.util.NestedTableSchemaHelper;
import com.google.dflab.util.YamlCoder;
import com.google.common.collect.ImmutableList;

import java.util.Map;

import com.google.dflab.combine.CustomOptions;
import com.google.dflab.transforms.CsvParserFn;
import com.google.dflab.transforms.MergeSubRecordsFn;

/**
 * 
 * WriteBQ as a data flow template
 * <p>
 * The example reads a simple CSV file
 *
 * <p>
 * To run this starter example locally using DirectRunner, just execute it
 * without any additional parameters from your favorite development environment.
 * use options: --input=<csv inut file> --output=<output file> --headerYaml=
 * --bqErrors=<project>.<dataset>.
 * <table>
 * 
 */
public class WriteCombinedBQ {
	private static final Logger LOG = LoggerFactory.getLogger(WriteCombinedBQ.class);

	public static void WriteErrors(PCollection<ConversionError> errors, CustomOptions options) {
		errors.apply(
				BigQueryIO.<ConversionError>write().to(options.getBqErrorsTable())
						.withSchema(new TableSchema().setFields(ImmutableList.<TableFieldSchema>of(
								new TableFieldSchema().setName("msg").setType("STRING"),
								new TableFieldSchema().setName("colIdx").setType("INTEGER"),
								new TableFieldSchema().setName("name").setType("STRING"),
								new TableFieldSchema().setName("dType").setType("STRING"),
								new TableFieldSchema().setName("value").setType("STRING"),
								new TableFieldSchema().setName("createdDate").setType("DATETIME"))))
						.withFormatFunction(convError -> new TableRow().set("msg", convError.getMsg())
								.set("colIdx", convError.getColIdx()).set("name", convError.getName())
								.set("dType", convError.getDType()).set("value", convError.getValue())
								.set("createdDate", convError.getCreatedDate()))
						.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
	}

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		PipelineOptionsFactory.register(CustomOptions.class);
		CustomOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(CustomOptions.class);

		Pipeline p = Pipeline.create(options);

		// read the header file to be used as a side input

		PCollection<Map<String, Object>> headers = p.apply("Identify File", Create.of(options.getHeaderyaml().get()))
				.apply("read yaml", ParDo.of(new ReadYamlFn())).setCoder(new YamlCoder());

		PCollectionView<Map<String, Object>> headerView = headers.apply("Convert to View", View.asSingleton());

		PCollectionTuple mappedWithSideOutputs = p.apply("read csv data file", TextIO.read().from(options.getInput()))
				.apply("split into fields", ParDo.of(new CsvParserFn())).apply("validate",
						ParDo.of(new TransformWithErrorOutputFn(headerView)).withSideInputs(headerView).withOutputTags(
								TransformWithErrorOutputFn.mainOutputTag,
								TupleTagList.of(TransformWithErrorOutputFn.ErrorTag)));

		PCollection<ConversionError> errors = mappedWithSideOutputs.get(TransformWithErrorOutputFn.ErrorTag);
		WriteErrors(errors, options);

		PCollection<Map<String, String>> mapped = mappedWithSideOutputs.get(TransformWithErrorOutputFn.mainOutputTag);
		PCollection<KV<String, Map<String, String>>> keyedList = mapped.apply("Extract key",
				MapElements.via(new SimpleFunction<Map<String, String>, KV<String, Map<String, String>>>() {
					@Override
					public KV<String, Map<String, String>> apply(Map<String, String> record) {
						String key = record.get("icp_identifier");
						if (key == null) {
							key = "";
						}
						return KV.of(key, record);
					}
				}));
		
		PCollection<KV<String, Iterable<Map<String, String>>>> grouped = keyedList.apply("group By Key",
				GroupByKey.create());
		
		PCollection<MeterRecord> meterRecords = grouped.apply("MergeAllSubRecords", ParDo.of(new MergeSubRecordsFn()));

		 WriteResult f = meterRecords.apply("WriteResults2BQ",
				BigQueryIO.<MeterRecord>write().to(options.getCombinedValuesBqTable())
						.withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND)
						.withSchema(NestedTableSchemaHelper.mkTableSchema())
						.withFormatFunction(NestedTableSchemaHelper.mkFormatFunction())

		);
		 

		p.run();

	}
}
