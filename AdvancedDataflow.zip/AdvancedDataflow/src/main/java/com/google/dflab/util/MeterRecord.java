/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.util;

import java.util.Map;

import org.apache.beam.sdk.coders.DefaultCoder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.beam.sdk.coders.AvroCoder;

/**
 * Class MeterRecord
 * this class represents the grouped detail records in the original 
 * source file.
 * 
 * @author stephanmeyn
 *
 */
@DefaultCoder(AvroCoder.class)
public class MeterRecord {

	String icp_identifier;
	Map<String, String> meter_summary;
	List<Map<String, String>> meter_install;
	List<Map<String, String>> meter_component;
	List<Map<String, String>> meter_channel;

	public MeterRecord() {
		icp_identifier = "";
		meter_summary = new HashMap<String, String>();
		meter_install = new ArrayList<Map<String, String>>();
		meter_component = new ArrayList<Map<String, String>>();
		meter_channel = new ArrayList<Map<String, String>>();
	}

	public String getIcp_identifier() {
		return icp_identifier;
	}

	public void SetIcp_identifier(String value) {
		icp_identifier = value;
	}

	public Map<String, String> getMeter_summary() {
		return meter_summary;
	}

	public void setMeter_summary(Map<String, String> value) {
		meter_summary = value;
	}

	public List<Map<String, String>> getMeter_install() {
		return meter_install;
	}

	public void setMeter_install(List<Map<String, String>> value) {
		meter_install = value;
	}

	public List<Map<String, String>> getMeter_component() {
		return meter_component;
	}

	public void setMeter_component(List<Map<String, String>> value) {
		meter_component = value;
	}

	public List<Map<String, String>> getMeter_channel() {
		return meter_channel;
	}

	public void setMeter_channel(List<Map<String, String>> value) {
		meter_channel = value;
	}

	/** convenience function */
	public void put(String name, List<Map<String, String>> value) {
		switch (name) {
		case "meter_install":
			meter_install = value;
			break;
		case "meter_component":
			meter_component = value;
			break;
		case "meter_channel":
			meter_channel = value;
			break;
		}
	}

	/** convenience function */
	public List<Map<String, String>> get(String name) {
		List<Map<String, String>> result = null;
		switch (name) {
		case "meter_install":
			result = meter_install;
			break;
		case "meter_component":
			result = meter_component;
			break;
		case "meter_channel":
			result = meter_channel;
			break;
		}
		return result;
	}
}
