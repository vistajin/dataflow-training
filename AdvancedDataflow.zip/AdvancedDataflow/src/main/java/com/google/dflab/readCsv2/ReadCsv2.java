/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.google.dflab.readCsv2;

import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.apache.beam.sdk.transforms.Sum;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.Combine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.google.dflab.transforms.CsvParserFn;
import com.google.dflab.transforms.ReadYamlFn;
import com.google.dflab.transforms.TransformFn;
import com.google.dflab.util.YamlCoder;

import java.util.Map;

/**
 * ReadCsv1
 * <p>
 * The example :
 *    reads a Yaml file and transforms it into a map
 *    reads CSV files based on input options
 *    transforms the csv file by applying the map above to add field names
 *
 * <p>
 * To run this starter example locally using DirectRunner, just execute it
 * without any additional parameters from your favorite development environment.
 *  use options:
 *  --input=<csv input file>
 *  --output=<output file>
 *  --headeryaml=<yaml file>
 * <p>
 * To run this starter example using managed resource in Google Cloud Platform,
 * you should specify the following command-line options:
 * --project=<YOUR_PROJECT_ID>
 * --stagingLocation=<STAGING_LOCATION_IN_CLOUD_STORAGE> 
 * --runner=DataflowRunner*  --input=<csv inut file>
 *  --output=<output file>
 *  --headeryaml=<yaml file>
 **/
public class ReadCsv2 {
	private static final Logger LOG = LoggerFactory.getLogger(ReadCsv2.class);

	@SuppressWarnings("serial")
	public static void main(String[] args) {
		PipelineOptionsFactory.register(CustomOptions.class);
		CustomOptions options = PipelineOptionsFactory.fromArgs(args).withValidation().as(CustomOptions.class);

		Pipeline p = Pipeline.create(options);

		//read the header file to be used as a side input
		
		@SuppressWarnings("unchecked")
		PCollection<?> headers = p.apply("Identify File", Create.of(options.getHeaderyaml()))		 
				.apply("read yaml", ParDo.of(new ReadYamlFn()))
				.setCoder( new YamlCoder());   
		
		PCollectionView<Map<String, Object>> headerView = (PCollectionView<Map<String, Object>>) headers
				.apply("Convert to View", View.asSingleton());
	 
				  
		PCollection<Map<String, String>> mapped =
		p.apply("read csv data file", TextIO.read().from(options.getInput()))
				.apply("split into fields", ParDo.of(new CsvParserFn()))
				.apply("validate", ParDo.of(new TransformFn(headerView)).withSideInputs(headerView));
		
		
		mapped.apply("Extract key", MapElements.via(new SimpleFunction<Map<String, String>, KV<String, Integer>>() {
					@Override
					public KV<String, Integer> apply(Map<String, String> record) {
						String key = (String)record.get("record_type");
						if (key == null) {
							key = "No Record Type field";
						}
						return KV.of(key, 1);
					}
				}))
				.apply("count by key", Combine.<String, Integer, Integer>perKey(Sum.ofIntegers()))
				.apply("Format for output",
						MapElements.into(TypeDescriptors.strings())
								.via((KV<String, Integer> kv) -> String.format("%s: %d", kv.getKey(), kv.getValue())))
				.apply("output", TextIO.write().to(options.getOutput()));

		p.run();
		
	}
}
