/*
 * Copyright Google Inc. 2016
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
  */
package com.google.dflab.transforms;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.TupleTag;

import java.text.SimpleDateFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.dflab.util.ConversionError;
import com.google.dflab.util.HeaderHelper;

/**
 * Transform a row of strings into a HashMap. Uses Header Info to apply column
 * names and to validate formats Write transformation errors to a side output
 * 
 * @author stephanmeyn
 *
 */
@SuppressWarnings("serial")
public class TransformWithErrorOutputFn extends DoFn<List<String>, Map<String, String>> {

	private static final Logger LOG = LoggerFactory.getLogger(TransformWithErrorOutputFn.class);
	private PCollectionView<Map<String, Object>> headerView;
	private Counter errCounter = Metrics.counter(TransformFn.class, "transform-errors");

	/* define the tupleTagLists */
	final public static TupleTag<Map<String, String>> mainOutputTag = new TupleTag<Map<String, String>>() {
	};
	// Output that contains errors.
	final public static TupleTag<ConversionError> ErrorTag = new TupleTag<ConversionError>() {
	};

	public TransformWithErrorOutputFn(final PCollectionView<Map<String, Object>> headerView) {
		this.headerView = headerView;
	}

	/**
	 * validate the item conforms to the format type, return formatted value. in
	 * case of a formatting error return null
	 */
	private String checkFormat(String formatType, String value, OutputReceiver<ConversionError> err, String name,
			int colNr, List<String> row) {
		if ((value == null) || value.equals(""))
			return ""; // empty fields always comply
		if ((formatType == null) || formatType.equals(""))
			return value; // empty formatyype always complies
		if (formatType.equals("string"))
			return value;
		if (formatType.equals("int"))
			try {
				Integer.parseInt(value);
				return value; // keep its native form
			} catch (NumberFormatException ex) {
				err.output(new ConversionError("Format Error: " + ex.getMessage(), colNr, name, row));
				return null;
			}
		// reformat dates so that BigQuery accepts them
		if (formatType.equals("date"))
			try {
				SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy");
				SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd");
				return outputFormat.format(inputFormat.parse(value));

			} catch (Exception ex) {
				err.output(new ConversionError("Format Error: " + ex.getMessage(), colNr, name, row));
				return null;
			}
		// reformat dateTime  so that BigQuery accepts them
		if (formatType.equals("datetime"))
			try {
				SimpleDateFormat inputFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
				SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.S");
				return outputFormat.format(inputFormat.parse(value));
			} catch (Exception ex) {
				err.output(new ConversionError("Format Error: " + ex.getMessage(), colNr, name, row));
				return null;
			}
		return "Unkown formatType to check: " + formatType;

	}

	/**
	 * map the list of field values into a Hashmap using the header info. Also
	 * validate formats for int and date, datetime and return as strings suitable
	 * for input
	 * 
	 * @param List<String>
	 *            column values
	 * @param columnInfo
	 *            Column Details for the base type
	 * @param extraInfo
	 *            Column details for the sub type
	 * @param err
	 * @return a Map or null in the case of errors
	 */
	private Map<String, String> transform(List<String> row, List<Map<String, Object>> columnInfo,
			List<Map<String, Object>> extraInfo, OutputReceiver<ConversionError> err) {

		boolean hasErrors = false;
		final Map<String, String> result = new HashMap<String, String>();
		int expectedRowSize = columnInfo.size();
		// iterate columnInfo first
		if (columnInfo != null) {
			for (Map<String, Object> colData : columnInfo) {
				int colNr = (int) colData.get("column");
				if ((colNr >= 0) && (colNr < row.size())) {
					String name = (String) colData.get("name");

					String val = row.get(colNr);
					if (val == null) {
						val = "";
					}
					String formattedValue = checkFormat((String) colData.get("registry_data_type"), val, err, name,
							colNr, row);
					if (formattedValue == null) {
						errCounter.inc();
						hasErrors = true;
					} else
						result.put(name, formattedValue);
				}
			}
		}
		// iterate optional extra columnInfo
		if (extraInfo != null) {
			expectedRowSize += extraInfo.size();
			for (Map<String, Object> colData : extraInfo) {
				int colNr = (int) colData.get("column");
				if ((colNr >= 0) && (colNr < row.size())) {
					String name = (String) colData.get("name");
					String val = row.get(colNr);
					if (val == null) {
						val = "";
					}
					String formattedValue = checkFormat((String) colData.get("registry_data_type"), val, err, name,
							colNr, row);
					if (formattedValue == null) {
						errCounter.inc();
						hasErrors = true;
					} else
						result.put(name, formattedValue);
				}
			}
		} else if (row.size() < expectedRowSize) {
			errCounter.inc();
			err.output(new ConversionError(
					String.format("Input record has less fields %d vs expected %d", row.size(), expectedRowSize), -1,
					"", row));
		}
		if (hasErrors)
			return null;
		else
			return result;
	}

	@ProcessElement
	/**
	 * process an element. check field formats and output to error output of any
	 * errors are found
	 * 
	 */
	public void processElement(@Element List<String> row, MultiOutputReceiver out, ProcessContext c) throws Exception {
		Map<String, Object> headers = c.sideInput(this.headerView);
		Map<String, String> result = null;
		String mainType = row.get(0);
		List<Map<String, Object>> columnInfo = HeaderHelper.getColumnInfoList(headers, mainType);
		if (mainType.equals("HDR")) {
			result = this.transform(row, columnInfo, null, out.get(ErrorTag));
		} else if (mainType.equals("DET")) {
			List<Map<String, Object>> extraInfo = HeaderHelper.getColumnInfoList(headers, row.get(2));
			result = this.transform(row, columnInfo, extraInfo, out.get(ErrorTag));
			String extraName = HeaderHelper.mappedName(row.get(2));
			if (result != null)
				result.put("event_type", extraName);

		} else {
			LOG.warn(String.format(" Unidentified record Type: '%s'", mainType));
			out.get(ErrorTag).output(
					new ConversionError(String.format("Unidentified record Type: '%s'", mainType), -1, "", row));
		}

		if (result != null)
			out.get(mainOutputTag).output(result);
	}
}
