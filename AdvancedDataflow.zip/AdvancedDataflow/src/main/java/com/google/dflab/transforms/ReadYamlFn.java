/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.transforms;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Reader;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.apache.beam.sdk.io.FileSystems;
import org.apache.beam.sdk.io.fs.MatchResult;
import org.apache.beam.sdk.io.fs.ResourceId;
import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.yaml.snakeyaml.Yaml;

/**
 * DoFn to read a YAML file and return its content as a single element
 * 
 * Demonstrates:
 *  - use of FileSystem (which is independent of the type of the FS)
 *  - File Reading
 *  - Yaml conversion
 * 
 * @author stephanmeyn
 *
 */
@SuppressWarnings("serial")
public class ReadYamlFn extends DoFn<String, Map<String, Object>> {
	private static final Logger LOG = LoggerFactory.getLogger(ReadYamlFn.class);

	@ProcessElement
	public void processElement(ProcessContext c) throws Exception {
		String path = (String) c.element();

		try {
			MatchResult match = FileSystems.match(path);
			if (match.metadata().size() == 0) {
				throw new FileNotFoundException(path);
			}

			ResourceId inputFile = match.metadata().get(0).resourceId();
			LOG.info("Processing file {}", inputFile.getFilename());

			ReadableByteChannel readerChannel = FileSystems.open(inputFile);
			Reader reader = Channels.newReader(readerChannel, StandardCharsets.UTF_8.name());
			Yaml yaml = new Yaml();
			Map<String, Object> results = yaml.load(reader);

			readerChannel.close();

			c.output(results);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
