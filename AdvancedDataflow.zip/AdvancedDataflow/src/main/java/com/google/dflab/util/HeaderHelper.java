/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * HeaderHelper - a class to help extract information out of the yaml based
 * header file
 * 
 * @author stephanmeyn
 *
 */
public class HeaderHelper {

	private static final Logger LOG = LoggerFactory.getLogger(HeaderHelper.class);
	private static Map<String, String> metaMap = initMetaMap();

	private HeaderHelper() {

	}

	/*
	 * the CSV data file uses keywords that are different to the keywords used in
	 * the Header file. So lets map the translation here
	 */
	private static Map<String, String> initMetaMap() {
		Map<String, String> result = new HashMap<String, String>();
		result.put("HDR", "header");
		result.put("DET", "detail");
		result.put("METERSUMMARY", "meter_summary");
		result.put("METERINSTALL", "meter_install");
		result.put("METERCOMP", "meter_component");
		result.put("METERCHANNEL", "meter_channel");
		return result;
	}

	public static String mappedName(String name) {
		return metaMap.get(name);
	}

	/**
	 * for the purpose of this exercise, we need the column information in the
	 * header file. This method extracts it easily
	 * 
	 * @param currentData
	 *            : the yaml file based dictionary
	 * @param recordType
	 *            : the data type to use
	 * @return : the column information for that data type
	 */
	public static List<Map<String, Object>> getColumnInfoList(Map<String, Object> currentData, String recordType) {
		// MainType is any of the metaMap keys"
		String translated = mappedName(recordType);
		if (translated == null) {
			LOG.warn("unknown Record type '%s'", recordType);
			return null;
		}
		Map<String, Object> info = (Map<String, Object>) currentData.get(translated);
		if (info == null) {
			LOG.error("info is null on looking for '" + translated + "'");
			for (String key : currentData.keySet())
				LOG.error("  key='" + key + "'");

		}
		List<Map<String, Object>> columnInfoList = (List<Map<String, Object>>) info.get("columns");

		return columnInfoList;
	}

}
