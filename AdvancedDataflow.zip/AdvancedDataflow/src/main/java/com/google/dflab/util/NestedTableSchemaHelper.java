/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.util;

import java.util.List;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import org.apache.beam.sdk.transforms.SerializableFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;

/**
 * This helper class provides a table schema and a format function required 
 * to write MeterRecords to BigQuery
 * 
 * @author stephanmeyn
 *
 */
public class NestedTableSchemaHelper {

	private static final Logger LOG = LoggerFactory.getLogger(NestedTableSchemaHelper.class);

	public static TableSchema mkTableSchema() {
		TableSchema result = new TableSchema();
		result.setFields(Arrays.asList(new TableFieldSchema().setName("icp_identifier").setType("STRING") ,
				
				new TableFieldSchema().setName("meter_summary").setType("RECORD")
						.setFields(Arrays.asList(new TableFieldSchema().setName("event_audit_number").setType("STRING"),
								new TableFieldSchema().setName("event_date").setType("DATE"),
								
								new TableFieldSchema().setName("event_creation_date_time").setType("DATETIME"),
								new TableFieldSchema().setName("created_by").setType("STRING"),
								new TableFieldSchema().setName("event_state").setType("STRING"),
								new TableFieldSchema().setName("reversed_replaced_date").setType("DATE"),
								new TableFieldSchema().setName("reversed_replaced_by").setType("STRING"),
								new TableFieldSchema().setName("reversal_replacement_file_name").setType("STRING"),
								new TableFieldSchema().setName("replacement_event_audit_number").setType("STRING"),
								new TableFieldSchema().setName("metering_equipment_provider").setType("STRING"),
								new TableFieldSchema().setName("meter_multipler_flag").setType("STRING"),
								new TableFieldSchema().setName("pp_flag").setType("STRING"),
								new TableFieldSchema().setName("hhr_flag").setType("STRING"),
								new TableFieldSchema().setName("nhh_flag").setType("STRING"),
								new TableFieldSchema().setName("ami_flag").setType("STRING"),
							 	new TableFieldSchema().setName("meter_user_reference").setType("STRING"),
								new TableFieldSchema().setName("highest_metering_category").setType("STRING"),
								new TableFieldSchema().setName("meter_register_count").setType("STRING") )),
				new TableFieldSchema().setName("meter_install").setType("RECORD").setMode("REPEATED")
						.setFields(Arrays.asList(
								new TableFieldSchema().setName("meter_installation_number").setType("STRING"),
								new TableFieldSchema().setName("highest_metering_category").setType("STRING"),
								new TableFieldSchema().setName("metering_installation_location_code").setType("STRING"),
								new TableFieldSchema().setName("ath_participant_identifier").setType("STRING"),
								new TableFieldSchema().setName("meter_installation_type").setType("STRING"),
								new TableFieldSchema().setName("meter_installation_certification_type")
										.setType("STRING"),
								new TableFieldSchema().setName("meter_installation_certification_date").setType("DATE"),
								new TableFieldSchema().setName("meter_installation_certification_expiry_date")
										.setType("DATE"),
								new TableFieldSchema().setName("control_device_certification_flag").setType("STRING"),
								new TableFieldSchema().setName("certifications_variations").setType("STRING"),
								new TableFieldSchema().setName("certifications_variations_expiry_date").setType("DATE"),
								new TableFieldSchema().setName("certification_number").setType("STRING"),
								new TableFieldSchema().setName("maximum_interroggation_cycle").setType("STRING"),
								new TableFieldSchema().setName("lease_price_code").setType("STRING")

				)),
				new TableFieldSchema().setName("meter_component").setType("RECORD").setMode("REPEATED")
						.setFields(Arrays.asList(
								new TableFieldSchema().setName("meter_installation_number").setType("STRING"),
								new TableFieldSchema().setName("meter_component_serial_number").setType("STRING"),
								new TableFieldSchema().setName("meter_component_type").setType("STRING"),
								new TableFieldSchema().setName("meter_type").setType("STRING"),
								new TableFieldSchema().setName("ami_flag").setType("STRING"),
								new TableFieldSchema().setName("meter_installation_catergory").setType("STRING"),
								new TableFieldSchema().setName("compensation_factor").setType("STRING"),
								new TableFieldSchema().setName("owner").setType("STRING"),
								new TableFieldSchema().setName("removal_date").setType("DATE"))) ,
				new TableFieldSchema().setName("meter_channel").setType("RECORD").setMode("REPEATED")
						.setFields(Arrays.asList(
								new TableFieldSchema().setName("meter_installation_number").setType("STRING"),
								new TableFieldSchema().setName("meter_component_serial_number").setType("STRING"),
								new TableFieldSchema().setName("channel_number").setType("STRING"),
								new TableFieldSchema().setName("number_of_dials").setType("STRING"),
								new TableFieldSchema().setName("register_content_code").setType("STRING") ,
								new TableFieldSchema().setName("period_of_availability").setType("STRING"),
								new TableFieldSchema().setName("unit_of_measure").setType("STRING"),
								new TableFieldSchema().setName("energy_flow_direction").setType("STRING") ,
								new TableFieldSchema().setName("accumulator_type").setType("STRING"),
								new TableFieldSchema().setName("settlement_indicator").setType("STRING")  ,
								new TableFieldSchema().setName("event_reading").setType("STRING") /**/
								))
				)
				);

		return result;
	}

	/**
	 * create the mapping function that maps the record to a table row, considering
	 * nested records
	 */
	@SuppressWarnings("serial")
	public static SerializableFunction<MeterRecord, TableRow> mkFormatFunction() {
		SerializableFunction<MeterRecord, TableRow> resultFn = new SerializableFunction<MeterRecord, TableRow>() {

			private TableRow mapMap2Row(Map<String, String> input) {
				TableRow resultRow = new TableRow();
				for (String fieldName : input.keySet()) {
					resultRow.set(fieldName, input.get(fieldName));
				}
				return resultRow;
			}

			private ArrayList<TableRow> mapList2Row(List<Map<String, String>> input) {
				ArrayList<TableRow> result = new ArrayList<TableRow>();
				for (Map<String, String> repeatedInput : input) {
					result.add(mapMap2Row(repeatedInput));
				}
				return result;
			}

			private void processNestedRepeated(TableRow target, String keyName, MeterRecord input) {
				List<Map<String, String>> theMap = input.get(keyName);
				if (theMap != null) {
					target.set(keyName, mapList2Row(theMap));
				} else {
					LOG.warn(keyName + " missing");
					//target.set(keyName, new ArrayList<TableRow>());
				}
			}

			@Override
			public TableRow apply(MeterRecord input) {
				TableRow row = new TableRow();
				Object o = input.getMeter_summary();
				String oName = o.getClass().getName();
				row.set("icp_identifier", input.getIcp_identifier());

				Map<String, String> meterSummary = input.getMeter_summary();
				if (meterSummary != null) {
				 	row.set("meter_summary", mapMap2Row(meterSummary));
				} else {
					LOG.warn("Meter Summary missing");
				}
				processNestedRepeated(row, "meter_install", input);
 				processNestedRepeated(row, "meter_component", input);
 				processNestedRepeated(row, "meter_channel", input);
				return row;
			}
		};
		LOG.info("Constructed mapping fn");
		return resultFn;
	}

}
