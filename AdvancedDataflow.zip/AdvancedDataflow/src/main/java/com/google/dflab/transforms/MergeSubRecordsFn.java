/*
 * Copyright Google Inc. 2016 Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with the
 * License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */
package com.google.dflab.transforms;

import java.util.HashMap;
import java.util.Map;
import java.util.List;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.dflab.util.MeterRecord;

/**
 * Build out of the group a single object that has nested fields: icp_identifier
 * is the key the event_types represent nested fields event_type ==
 * 'meter_summary' occurs only once, so this is a nested record all other event
 * types occur multiple times, they are nested repeated records
 * 
 * @author stephanmeyn
 *
 */
@SuppressWarnings("serial")
public class MergeSubRecordsFn extends DoFn<KV<String, Iterable<Map<String, String>>>, MeterRecord> {
	
	private static final Logger LOG = LoggerFactory.getLogger(MergeSubRecordsFn.class);
	
	
	@ProcessElement
	public void processElement(ProcessContext c) throws Exception {
		KV<String, Iterable<Map<String, String>>> input = (KV<String, Iterable<Map<String, String>>>) c.element();
		if (input.getKey().equals("")) {
			LOG.info("Skipped record with empty key");
			return;
		}
		MeterRecord result = new MeterRecord();
		result.SetIcp_identifier(input.getKey());
		 //LOG.info("Key: " +input.getKey());

		Iterable<Map<String, String>> contents = input.getValue();

		for (Map<String, String> subRow : contents) {
			String event = subRow.getOrDefault("event_type", "no Event Type");
			//LOG.info("Event:"  + event);

			/* filter out fields we don't need */
			Map<String, String> cleanedRow = new HashMap<String, String> ();
			for (String key : subRow.keySet()) {
				if (key.equals("event_type"))
					continue;
				if (key.equals("icp_identifier"))
					continue;
				if (key.equals("DET"))
					continue;
				if (key.equals("RowType"))
					continue;
				cleanedRow.put(key, subRow.get(key));
			}
			if (event.equals("meter_summary")) { // summary only occurs once
				result.setMeter_summary(cleanedRow);
			} else {
				// all other elements occur multiple times so it has to be a list
				List<Map<String, String>> theList = result.get(event);
				if (theList == null) {
					LOG.error(String.format("Invalid event rec: '%s'. key: '%s'", event, input.getKey()));
				}
				theList.add(cleanedRow);
			}			
		}
		c.output(result);
	}
}
