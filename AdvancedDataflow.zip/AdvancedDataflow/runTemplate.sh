#! /bin/bash
gcloud dataflow jobs run dffromtemplate \
   --gcs-location gs://stephanmeyn-corp-powerco/templates/writeBQTmpl \
--parameters=input=gs://stephanmeyn-corp-powerco/PR255_MeterInstInfo_20180816142145.txt,output=gs://stephanmeyn-corp-powerco/Poutput2.txt,headeryaml=gs://stephanmeyn-corp-powerco/pr255.yml